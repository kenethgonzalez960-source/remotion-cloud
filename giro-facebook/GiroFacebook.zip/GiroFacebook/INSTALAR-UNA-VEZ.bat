@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Falta instalar Node.js. Se abrira la pagina para descargarlo: boton LTS. Instalelo y vuelva a abrir este archivo.
  start https://nodejs.org
  pause
  exit /b
)
call npm install
echo.
echo Listo. Ya puede usar los archivos 1 y 2.
pause
