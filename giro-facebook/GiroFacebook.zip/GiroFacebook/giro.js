// Giro Facebook: modo "enlaces" (usted pega links) o "auto" (busca las noticias solo).
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync, spawn } = require('child_process');
const puppeteer = require('puppeteer-core');

const readline = require('readline');
const logFile = path.join(__dirname, 'ultimo-resultado.txt');
try { fs.writeFileSync(logFile, ''); } catch (e) {}
for (const k of ['log', 'error']) {
  const orig = console[k].bind(console);
  console[k] = (...a) => { orig(...a); try { fs.appendFileSync(logFile, a.join(' ') + '\n'); } catch (e) {} };
}
const modo = process.argv[2] || 'auto';
const hoy = new Date().toISOString().slice(0, 10);
const salida = process.env.GIRO_SALIDA || path.join(os.homedir(), 'Downloads', 'Giro Facebook', hoy);
fs.mkdirSync(salida, { recursive: true });
const log = (m) => console.log('[Giro] ' + m);

const REGLAS = `REGLAS DEL CANAL (obligatorias):
- Canal "Giro Hacia La Izquierda", de un abogado penalista colombiano, línea progresista. Enfoque siempre crítico contra el gobierno de Abelardo de la Espriella y la derecha.
- Solo hechos confirmados por al menos dos medios distintos o un documento oficial. Las denuncias se redactan como denuncia ("denuncian", "según", "la comunidad dice"). Nunca presentes una denuncia como hecho probado.
- Prohibido inventar citas, cifras, fechas, nombres o titulares. El titular del recorte debe ser el titular REAL y textual del medio.
- Título corto en MAYÚSCULAS, con UNA palabra clave entre *asteriscos*. Texto de apoyo en dos párrafos, lenguaje hablado y cercano, frases de 15 a 25 palabras, sin frases de aire de IA. Prohibida la palabra "desnudamos".
- Sin línea "Fuente:" en el texto de la imagen. SIN NÚMEROS en las imágenes.
- Incluye siempre un dato de contexto del pasado y uno del futuro (solo si los encuentras en internet).`;

const FORMATO = `Responde SOLO con un arreglo JSON válido, sin texto antes ni después, así:
[{"titulo":"...","detalle":"párrafo 1\\n\\npárrafo 2","outlet":"nombre del medio del recorte","clipText":"titular real y textual","cardStyle":"serif|sans|naranja|azul","tint":"amarillo|rojo","persona":"nombre de la persona principal para buscar su foto (o vacío)","esDenuncia":true,"fuentes":[{"medio":"...","url":"..."}],"mensaje":"texto para pegar en Facebook, con llamado a comentar, dar like, compartir y suscribirse al canal en YouTube, y los hashtags #Colombia #GiroHaciaLaIzquierda"}]`;

function pedirAClaude(prompt) {
  log('Claude está trabajando (puede tardar varios minutos)...');
  const r = spawnSync('claude', ['-p', '--allowedTools', 'WebSearch,WebFetch'], {
    input: prompt, encoding: 'utf8', shell: true, maxBuffer: 64 * 1024 * 1024, timeout: 25 * 60 * 1000,
  });
  if (r.error || r.status !== 0) {
    console.error(r.stderr || r.error);
    throw new Error('No pude ejecutar Claude. Revise que Claude Code esté instalado y con la sesión iniciada (abra una ventana y escriba: claude).');
  }
  const t = r.stdout;
  const a = t.indexOf('['), b = t.lastIndexOf(']');
  if (a < 0 || b < 0) throw new Error('Claude no devolvió las piezas en el formato esperado:\n' + t.slice(0, 600));
  const crudo = t.slice(a, b + 1);
  try { return JSON.parse(crudo); } catch (e) {
    // arregla saltos de línea sueltos dentro de los textos
    let out = '', dentro = false, esc = false;
    for (const ch of crudo) {
      if (dentro && !esc && (ch === '\n' || ch === '\r')) { out += ch === '\n' ? '\\n' : ''; continue; }
      if (ch === '"' && !esc) dentro = !dentro;
      esc = ch === '\\' && !esc;
      out += ch;
    }
    return JSON.parse(out);
  }
}

function promptAuto() {
  return `Hoy es ${hoy}. Busca en internet las noticias de las últimas 24 horas sobre escándalos y decisiones polémicas del gobierno de Abelardo de la Espriella, sus ministros, aliados y la derecha en Colombia. Escoge 3 hechos y crea una pieza por hecho.\n\n${REGLAS}\n\n${FORMATO}`;
}
function promptEnlaces(urls) {
  return `Lee estas noticias con WebFetch y complétalas con búsquedas en internet para confirmar cada hecho con un segundo medio. Crea una pieza por noticia (si son varias del mismo hecho, una sola pieza).\n\nENLACES:\n${urls.join('\n')}\n\n${REGLAS}\n\n${FORMATO}`;
}

async function fotoLibre(nombre, destino) {
  if (!nombre) return null;
  // 1) fotos propias: mis-fotos/<nombre>.png|jpg
  const slug = nombre.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const carpeta = path.join(__dirname, 'mis-fotos');
  for (const f of fs.existsSync(carpeta) ? fs.readdirSync(carpeta) : []) {
    const base = f.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\.[a-z]+$/, '').replace(/[^a-z0-9]+/g, '-');
    if (base && slug.includes(base)) return { archivo: path.join(carpeta, f), autor: 'foto propia', licencia: 'propia', url: '' };
  }
  // 2) Wikimedia Commons con licencia libre
  try {
    const q = encodeURIComponent(nombre + ' filetype:bitmap');
    const u = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${q}&gsrnamespace=6&gsrlimit=15&prop=imageinfo&iiprop=url|extmetadata|mime&iiurlwidth=1100&format=json`;
    const j = await (await fetch(u, { headers: { 'User-Agent': 'GiroFacebook/1.0 (uso editorial)' } })).json();
    const pags = Object.values((j.query && j.query.pages) || {});
    for (const p of pags) {
      const ii = p.imageinfo && p.imageinfo[0]; if (!ii || ii.mime !== 'image/jpeg') continue;
      const lic = (ii.extmetadata.LicenseShortName || {}).value || '';
      if (!/(CC0|CC BY|CC BY-SA|Public domain|PD)/i.test(lic) || /NC|ND/i.test(lic)) continue;
      const r = await fetch(ii.thumburl, { headers: { 'User-Agent': 'GiroFacebook/1.0' } });
      if (!r.ok) continue;
      fs.writeFileSync(destino, Buffer.from(await r.arrayBuffer()));
      const autor = ((ii.extmetadata.Artist || {}).value || 'autor no indicado').replace(/<[^>]+>/g, '').trim();
      return { archivo: destino, autor, licencia: lic, url: ii.descriptionurl };
    }
  } catch (e) { log('No pude buscar foto en Commons: ' + e.message); }
  return null;
}

function buscarNavegador() {
  const c = [process.env.CHROME_PATH,
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(os.homedir(), 'AppData\\Local\\Google\\Chrome\\Application\\chrome.exe'),
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/usr/bin/google-chrome', '/opt/pw-browsers/chromium'];
  const ok = c.find((p) => p && fs.existsSync(p));
  if (!ok) throw new Error('No encontré Chrome ni Edge en el computador.');
  return ok;
}

async function renderizar(piezas) {
  const browser = await puppeteer.launch({ executablePath: buscarNavegador(), headless: true, args: ['--no-sandbox', '--allow-file-access-from-files'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1200, height: 900 });
  await page.goto('file://' + path.resolve(__dirname, 'generador.html').replace(/\\/g, '/'));
  await new Promise((r) => setTimeout(r, 3000));
  for (let i = 0; i < piezas.length; i++) {
    const p = piezas[i];
    await page.evaluate((p) => {
      const set = (id, v, ev) => { const e = document.getElementById(id); e.value = v; e.dispatchEvent(new Event(ev || 'input', { bubbles: true })); };
      document.querySelector('#tmplChips button[data-id="collage"]').click();
      set('size', '1080x1350', 'change');
      set('numero', ''); set('titulo', p.titulo || ''); set('detalle', p.detalle || '');
      set('outlet', p.outlet || ''); set('clipText', p.clipText || '');
      set('cardStyle', p.cardStyle || 'sans', 'change'); set('tint', p.tint || 'amarillo', 'change'); set('underline', 'si', 'change');
      document.getElementById('clearCollage').click();
    }, p);
    if (p._foto) { const h = await page.$('#personPhoto'); await h.uploadFile(p._foto); }
    await new Promise((r) => setTimeout(r, 1800));
    const src = await page.evaluate(() => document.getElementById('out').src);
    fs.writeFileSync(path.join(salida, `pieza-${i + 1}.png`), Buffer.from(src.split(',')[1], 'base64'));
    log(`Imagen ${i + 1} lista`);
  }
  await browser.close();
}

(async () => {
  let piezas;
  if (modo === 'enlaces') {
    console.log('\nPegue aquí los enlaces de las noticias (uno por línea).');
    console.log('Cuando termine, presione Enter en una línea vacía.\n');
    const urls = await new Promise((res) => {
      const rl = readline.createInterface({ input: process.stdin });
      const got = [];
      let empezo = false;
      rl.on('line', (l) => {
        const t = l.trim();
        if (/^https?:\/\//.test(t)) { got.push(t); empezo = true; }
        else if (!t && empezo) rl.close();
      });
      rl.on('close', () => res(got));
    });
    if (!urls.length) throw new Error('No se recibió ningún enlace. Pegue enlaces que empiecen por http.');
    log(`${urls.length} enlace(s) encontrados`);
    piezas = pedirAClaude(promptEnlaces(urls));
  } else {
    piezas = pedirAClaude(promptAuto());
  }
  const respaldo = [`# Respaldo ${hoy}`, ''];
  for (let i = 0; i < piezas.length; i++) {
    const p = piezas[i];
    const texto = JSON.stringify(p);
    if (/desnudamos/i.test(texto) || /Fuente:/i.test(p.detalle || '')) respaldo.push(`> ADVERTENCIA pieza ${i + 1}: contiene una palabra o línea prohibida. Corríjala antes de publicar.`);
    if ((p.fuentes || []).length < 2) respaldo.push(`> ADVERTENCIA pieza ${i + 1}: tiene menos de dos fuentes. Verifíquela antes de publicar.`);
    if (/\d+\.\s*$/.test(p.titulo || '')) respaldo.push(`> ADVERTENCIA pieza ${i + 1}: el título termina en número.`);
    const foto = await fotoLibre(p.persona, path.join(salida, `foto-${i + 1}.jpg`));
    let credito = '';
    if (foto) { p._foto = foto.archivo; credito = `\n\nFoto: ${foto.autor} (${foto.licencia})`; }
    respaldo.push(`## Pieza ${i + 1}: ${(p.titulo || '').replace(/\*/g, '')}`, `Es denuncia: ${p.esDenuncia ? 'sí' : 'no'}`, 'Fuentes:');
    (p.fuentes || []).forEach((f) => respaldo.push(`- ${f.medio}: ${f.url}`));
    respaldo.push(foto ? `Foto: ${foto.autor}, licencia ${foto.licencia} ${foto.url}` : 'Foto: sin foto libre (la pieza sale sin persona)', 'Revise que el titular del recorte sea textual.', '');
    fs.writeFileSync(path.join(salida, `pieza-${i + 1}.txt`), (p.mensaje || '') + credito);
  }
  await renderizar(piezas);
  fs.writeFileSync(path.join(salida, 'respaldo.md'), respaldo.join('\n'));
  log('Todo listo en: ' + salida);
  const abre = process.platform === 'win32' ? ['explorer', [salida]] : process.platform === 'darwin' ? ['open', [salida]] : null;
  if (abre) spawn(abre[0], abre[1], { detached: true, stdio: 'ignore' }).unref();
})().catch((e) => { console.error('\nERROR: ' + e.message); process.exit(1); });
