@echo off
chcp 65001 >nul
echo Instalando Claude Code, espere un momento...
call npm install -g --allow-scripts=@anthropic-ai/claude-code @anthropic-ai/claude-code
echo.
echo Ahora se abrira Claude para iniciar sesion.
echo Elija la opcion de CUENTA DE CLAUDE CON SUSCRIPCION (no la de API key). Se abre el navegador: inicie sesion.
echo Cuando termine, escriba /exit y presione Enter.
echo.
pause
claude
echo.
echo Listo. Ya puede abrir 0-ABRIR-PANEL.bat
pause
