@echo off
chcp 65001 >nul
schtasks /create /tn "Giro Facebook diario" /tr "\"%~dp02-AUTOMATICO.bat\" silencioso" /sc daily /st 07:00 /f
echo Programado todos los dias a las 7:00 a.m. (el computador debe estar encendido).
pause
