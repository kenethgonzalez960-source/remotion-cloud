@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist node_modules (
  echo Instalando por primera vez, espere un momento...
  call npm install
)
node giro.js auto
echo.
if "%1"=="" pause
