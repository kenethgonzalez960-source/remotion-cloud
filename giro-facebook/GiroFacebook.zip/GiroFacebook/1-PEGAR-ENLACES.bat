@echo off
chcp 65001 >nul
cd /d "%~dp0"
type nul > enlaces.txt
echo Se abrira el Bloc de notas. Pegue los enlaces de las noticias (uno por linea), guarde (Ctrl+S) y cierre el Bloc de notas.
pause
notepad enlaces.txt
node giro.js enlaces
echo.
pause
