@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist node_modules (
  echo Instalando por primera vez, espere un momento...
  call npm install
)
echo Abriendo el panel en el navegador. DEJE ESTA VENTANA ABIERTA mientras trabaja.
node giro.js panel
echo.
echo Si hubo un error, quedo guardado en ultimo-resultado.txt
pause
